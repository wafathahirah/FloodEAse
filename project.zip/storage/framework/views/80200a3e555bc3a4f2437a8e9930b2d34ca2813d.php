<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>This is staff dashboard</h1>
    <?php if(session('user')): ?>
    <h2>Hello, <?php echo e(session('user')); ?></h2>
<?php endif; ?>
</body>
</html><?php /**PATH C:\Users\User\Documents\htdocs\FYPNEWW\resources\views/staff/staff_dashboard.blade.php ENDPATH**/ ?>