
<?php $__env->startSection('content'); ?>
    <link href="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Senarai Status Bantuan</h1>
            <div>
                <a data-toggle="modal" data-target="#createAidRes"
                    class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                    <i class="fas fa-plus fa-sm text-white-50"></i>
                </a>
                <a class="btn btn-sm btn-danger shadow-sm" href="<?php echo e(route('logout')); ?>" data-toggle="modal"
                    data-target="#deleteAllRecords">
                    <i class="fas fa-trash fa-sm text-white-50"></i>
                </a>
            </div>
        </div>

        <!-- DataTable -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="listAidRes" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Kumpulan</th>
                                <th>Lokasi</th>
                                <th>Status</th>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Kumpulan</th>
                                <th>Lokasi</th>
                                <th>Status</th>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $aid_res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aidRes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php if($aidRes->committee): ?>
                                        <?php if($aidRes->committee->staff): ?>
                                            <?php echo e($aidRes->committee->staff->SName); ?>

                                        <?php else: ?>
                                            Staff Not Found
                                        <?php endif; ?>
                                    <?php else: ?>
                                        Committee Not Found
                                    <?php endif; ?></td>                                
                                    <td><?php echo e($aidRes->resident->ResStreet); ?></td>
                                    <td><?php echo e($aidRes->aid_resStatus); ?></td>
                                    <td> <a href="#" data-toggle="modal" data-target="#deleteAidRes"><button
                                                class="btn btn-info view">Lihat</button></a></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal: Add -->
    <div class="modal fade" id="createAidRes" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Status Bantuan</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="<?php echo e(route('aid_res.store')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="ComID">Nama Ketua Kumpulan:</label>
                            <select name="ComID" id="ComID" class="form-control" required>
                                    <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e(sprintf('%012d', $staff->SID)); ?>"><?php echo e($staff->SName); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="ResID">Lokasi :</label>
                            <select name="ResID" class="form-control" required>
                                <?php $__currentLoopData = $resident; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($res->ResID); ?>"><?php echo e($res->ResStreet); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="AidID">Pakej Bantuan:</label>
                            <select name="AidID" class="form-control" required>
                                <?php $__currentLoopData = $aid->unique('AidType'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uniqueAid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($uniqueAid->AidID); ?>"><?php echo e($uniqueAid->AidType); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="aid_resQuantity">Jumlah Bantuan:</label>
                            <input type="text" name="aid_resQuantity" class="form-control" required>

                        </div>

                        <div class="form-group">
                            <label for="aid_resStatus">Status Bantuan:</label>
                            <select name="aid_resStatus" class="form-control" required>
                                <option value="" disabled selected>Sila Pilih</option>
                                <option value="Lebih">Lebih</option>
                                <option value="Kurang">Kurang</option>
                                <option value="Selesai">Selesai</option>
                            </select>
                        </div>
                        

                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                            <button class="btn btn-primary" type="submit">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Modal: Add-->

    <!-- Modal: Delete-->
    <div class="modal fade" id="deleteAllRecords" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Hapus Semua Rekod</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form method="POST" action="<?php echo e(route('delete-all')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <div class="modal-body">
                        <input type="hidden" name="_method" value="DELETE">
                        <p>Adakah anda pasti ingin menghapus semua rekod?</p>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Tutup</button>
                        <button class="btn btn-danger" type="submit">Hapus Semua</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.getElementById("PosName").addEventListener("input", function() {
            this.value = this.value.toUpperCase();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FYPNEWW\resources\views/admin/listAllLeaderLocation.blade.php ENDPATH**/ ?>