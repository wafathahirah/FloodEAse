<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-text mx-3">Haluan Kelantan</div>
    </a>

    

    <!-- Nav Item --->

    <li class="nav-item">
        <a class="nav-link" href=<?php echo e(route('jkk.dashboard')); ?>>
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Laman Utama</span></a>
    </li>


    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading 
    <div class="sidebar-heading">
        Addons
    </div> -->

    

    

</ul><?php /**PATH C:\xampp\htdocs\FYPNEWW - Copy\resources\views/jkk/sidebar.blade.php ENDPATH**/ ?>