
<?php $__env->startSection('content'); ?>
    <link href="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

    <div class="container-fluid">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Senarai Kakitangan</h1>
            <a data-toggle="modal" data-target="#createStaff"
                class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                    class="fas fa-plus fa-sm text-white-50"></i></a>
                    <?php echo $__env->make('admin.createStaff', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php echo $__env->make('components.errorMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- DataTable -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="listStaff" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>No. Telefon</th>
                                <th>Email</th>
                                <th>Peranan</th>
                                <th>Tindakan</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>No. Telefon</th>
                                <th>Email</th>
                                <th>Peranan</th>
                                <th>Tindakan</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($staff->SName); ?></td>
                                    <td><?php echo e($staff->SAddress); ?></td>
                                    <td><?php echo e($staff->SPhoneNum); ?></td>
                                    <td><?php echo e($staff->SEmail); ?></td>
                                    <td><?php echo e($staff->SRole); ?></td>

                                    <td>
                                        <a data-toggle="modal" data-target="#editStaff<?php echo e($staff->SID); ?>"><button
                                            class="btn btn-success editStaff"><i class="fa fa-pen"
                                                aria-hidden="true"></i></button></a> 
                                        <a href="delete/<?php echo e($staff->SID); ?>" onclick="return confirm ('Adakah anda pasti ingin menghapus kakitangan ini?')" data-tooltip="tooltip" data-html="true" data-placement="right"><button
                                                class="btn btn-danger"><i class="fa fa-trash"
                                                    aria-hidden="true"></i></button></a>

                                    </td>
                                    <?php echo $__env->make('admin.editStaff', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FYPNEWW - Copy\resources\views/admin/listAllStaff.blade.php ENDPATH**/ ?>