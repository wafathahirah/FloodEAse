<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; HALUAN</span>
        </div>
    </div>
</footer><?php /**PATH C:\Users\User\Documents\htdocs\FYPNEWW\resources\views/jkk/footer.blade.php ENDPATH**/ ?>