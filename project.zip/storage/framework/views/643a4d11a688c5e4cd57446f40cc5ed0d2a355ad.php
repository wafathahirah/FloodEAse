
<?php $__env->startSection('content'); ?>
    <link href="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

    <div class="container-fluid">
        <div class="container-fluid">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Senarai JawatanKuasa Kampung</h1>
                <a data-toggle="modal" data-target="#createPosition"
                    class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                        class="fas fa-plus fa-sm text-white-50"></i></a>
                <?php echo $__env->make('admin.createJKK', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php echo $__env->make('components.errorMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- DataTable -->
            <div class="card shadow mb-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="listJKK" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Kad Pengenalan</th>
                                    <th>Nama</th>
                                    <th>No. Telefon</th>
                                    <th>Emel</th>
                                    <th>Nama Kampung</th>
                                    <th>Tindakan</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Kad Pengenalan</th>
                                    <th>Nama</th>
                                    <th>No. Telefon</th>
                                    <th>Emel</th>
                                    <th>Nama Kampung</th>
                                    <th>Tindakan</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $JKK; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $JKK): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($JKK->JKKID); ?></td>
                                        <td><?php echo e($JKK->JKKName); ?></td>
                                        <td><?php echo e($JKK->JKKPhoneNum); ?></td>
                                        <td><?php echo e($JKK->JKKEmail); ?></td>
                                        <td><?php echo e($JKK->VillageName); ?></td>
                                        <td><a data-toggle="modal" data-target="#editJKK<?php echo e($JKK->JKKID); ?>"><button
                                                    class="btn btn-success editJKK"><i class="fa fa-pen"
                                                        aria-hidden="true"></i></button></a>
                                            <a href="delete/<?php echo e($JKK->JKKID); ?>" onclick="return confirm ('Adakah anda pasti ingin menghapus jawatankuasa kampung ini?')"><button
                                                    class="btn btn-danger"><i class="fa fa-trash"
                                                        aria-hidden="true"></i></button></a>
                                        </td>
                                        </td>
                                        <?php echo $__env->make('admin.editJKK', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FYPNEWW - Copy\resources\views/admin/listAllJKK.blade.php ENDPATH**/ ?>