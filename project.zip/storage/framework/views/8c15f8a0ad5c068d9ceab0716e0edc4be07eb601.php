
<!-- Modal: Edit-->
<div class="modal fade" id="editAid<?php echo e($aid->AidID); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Kemaskini Barang</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
        <div class="modal-body">
            <form method="POST" action="<?php echo e(route('update.aid', $aid->AidID)); ?>" id="editAid">
                <?php echo csrf_field(); ?>
               
                <div class="mb-3">
                    <label for="ItemName" class="form-label">Nama barang</label>
                    <input type="text" oninput="this.value = this.value.toUpperCase()" required class="form-control" id="ItemName" name="ItemName" value="<?php echo e($aid->ItemName); ?>">
                </div>

                <div class="mb-3">
                    <label for="TotalAid" class="form-label">Jumlah Barang</label>
                    <input type="number" class="form-control" id="TotalAid" required name="TotalAid" value="<?php echo e($aid->TotalAid); ?>">
                </div>

                <div class="mb-3">
                    <label for="AidType" class="form-label">Pakej</label>
                    <select required class="form-control" id="AidType" name="AidType">
                        <?php $__currentLoopData = ['Set Lelaki', 'Set Perempuan', 'Set Bayi', 'Makanan Sahaja']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($option); ?>" <?php if($option == $aid->AidType): ?> selected <?php endif; ?>><?php echo e($option); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>


                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    <button class="btn btn-primary" type="submit">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
<script>
$('.listAid').DataTable();

$(document).on('click', '.editAid', function() {
    var_this = $(this).parents('tr');

    $('#AidID').val(_this.find('.AidID').text());
    $('#ItemName').val(_this.find('.ItemName').text());
    $('#TotalAid').val(_this.find('.TotalAid').text());
    $('#AidType').val(_this.find('.AidType').text());
});

document.getElementById("ItemName").addEventListener("input", function() {
                            this.value = this.value.toUpperCase();
                        });
</script><?php /**PATH C:\xampp\htdocs\FYPNEWW - Copy\resources\views/admin/editAid.blade.php ENDPATH**/ ?>