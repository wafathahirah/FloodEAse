
<?php $__env->startSection('content'); ?>
    <link href="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Inventori</h1>
            <a data-toggle="modal" data-target="#createAid"
                class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                    class="fas fa-plus fa-sm text-white-50"></i></a>
                    <?php echo $__env->make('admin.createAid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
        <?php echo $__env->make('components.errorMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- DataTable -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="listAid" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Nama Item</th>
                                <th>Jumlah</th> 
                                <th>Pakej</th>
                                <th>Masa/tarikh kemaskini</th>
                                <th>Tindakan</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Nama Item</th>
                                <th>Jumlah</th> 
                                <th>Pakej</th>
                                <th>Masa/tarikh kemaskini</th>
                                <th>Tindakan</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $aid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($aid->ItemName); ?></td>
                                    <td><?php echo e($aid->TotalAid); ?></td>
                                    <td><?php echo e($aid->AidType); ?></td>
                                    <td><?php echo e($aid->updated_at->format('d-m-Y H:i:s')); ?></td>

                                    <td>

                                            <a data-toggle="modal" data-target="#editAid<?php echo e($aid->AidID); ?>"><button
                                                    class="btn btn-success editAid"><i class="fa fa-pen"
                                                        aria-hidden="true"></i></button></a><?php echo $__env->make('admin.editAid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                                        <a href="adminn/delete/<?php echo e($aid->AidID); ?>" onclick="return confirm ('Adakah anda pasti ingin menghapus barang ini?')" data-tooltip="tooltip" data-html="true" data-placement="right"><button
                                                            class="btn btn-danger"><i class="fa fa-trash"
                                                                aria-hidden="true"></i></button></a>
                                      
                                    </td>

                                    <td></td>
                                    <?php echo $__env->make('admin.editAid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FYPNEWW - Copy\resources\views/admin/listAllInventory.blade.php ENDPATH**/ ?>