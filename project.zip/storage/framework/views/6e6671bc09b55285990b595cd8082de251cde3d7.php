
<?php $__env->startSection('content'); ?>
    <link href="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Senarai Penduduk</h1>
        </div>
        <?php echo $__env->make('components.errorMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- DataTable -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="listRes" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Kad Pengenalan</th>
                                <th>Nama</th>
                                <th>Kondisi Rumah</th>
                                <th>Masa/Tarikh</th>
                                <th>Tindakan</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Kad Pengenalan</th>
                                <th>Nama</th>
                                <th>Kondisi Rumah</th>
                                <th>Masa/Tarikh</th>
                                <th>Tindakan</th>
                                <th></th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $resident; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resident): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($resident->ResID); ?></td>
                                    <td><?php echo e($resident->ResName); ?></td>
                                    <td><?php echo e($resident->HouseCondition); ?></td>
                                    <td><?php echo e($resident->updated_at->format('d-m-Y H:i:s')); ?></td>
                                    <td><a data-toggle="modal" data-target="#deleteRes<?php echo e($resident->ResID); ?>"><button
                                        class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></button></a>
                                        <a  data-toggle="modal" data-target="#viewRes<?php echo e($resident->ResID); ?>"><button
                                            class="btn btn-info"><i class="fa fa-eye"
                                            aria-hidden="true"></i></button></a>
                            </td>
                            <?php echo $__env->make('admin.deleteResident', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <td></td>
                                    
                        <?php echo $__env->make('admin.viewResident', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
                                    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FYPNEWW - Copy\resources\views/admin/listAllResident.blade.php ENDPATH**/ ?>