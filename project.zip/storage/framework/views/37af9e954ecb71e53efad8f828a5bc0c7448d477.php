
<?php $__env->startSection('content'); ?>
    <link href="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Senarai Ahli Jawatan Kuasa Misi</h1>
            <a data-toggle="modal" data-target="#createCommittee"
                class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                    class="fas fa-plus fa-sm text-white-50"></i></a>
                    <?php echo $__env->make('admin.createCommittee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php echo $__env->make('components.errorMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- DataTable -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="listCommittee" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Jawatan</th>
                                <th>Tugasan</th>
                                <th>Ketua</th>
                                <th>Tarikh lantikan</th>
                                <th>Tindakan</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Nama</th>
                                <th>Jawatan</th>
                                <th>Tugasan</th>
                                <th>Ketua</th>
                                <th>Tarikh lantikan</th>
                                <th>Tindakan</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $committee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $committee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($committee->staff->SName); ?></td>
                                    <td><?php echo e($committee->position->PosName); ?></td>
                                    <td><?php echo e($committee->ComTask); ?></td>
                                    <td><?php echo e($committee->ComLeader); ?></td>
                                    <td><?php echo e($committee->ComDate); ?></td>
                                    <td>
                                        
                                        <a href="#" data-toggle="modal" data-target="#editCommittee<?php echo e($committee->ComID); ?>"><button
                                                class="btn btn-success editCommittee"><i class="fa fa-pen" aria-hidden="true"></i></button></a>
                                                <a href="delete/<?php echo e($committee->ComID); ?>" onclick="return confirm ('Adakah anda pasti ingin menghapus ahli jawatankuasa ini ini?')" data-tooltip="tooltip" data-html="true" data-placement="right"><button
                                                    class="btn btn-danger"><i class="fa fa-trash"
                                                        aria-hidden="true"></i></button></a>

                                        
                                    </td>
                                    <?php echo $__env->make('admin.editCommittee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

                <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FYPNEWW - Copy\resources\views/admin/listAllCommittee.blade.php ENDPATH**/ ?>