
<?php $__env->startSection('content'); ?>
    <link href="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Senarai JawatanKuasa Misi</h1>
            <a data-toggle="modal" data-target="#createCommittee"
                class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                    class="fas fa-plus fa-sm text-white-50"></i></a>
        </div>

        <!-- DataTable -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="listCommittee" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Jawatan</th>
                                <th>Tugasan</th>
                                <th>Ketua</th>
                                <th>Tarikh lantikan</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Nama</th>
                                <th>Jawatan</th>
                                <th>Tugasan</th>
                                <th>Ketua</th>
                                <th>Tarikh lantikan</th>
                                <th></th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $committee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $committee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(optional($committee->staff)->SName); ?></td>
                                    <td><?php echo e($committee->position->PosName); ?></td>
                                    <td><?php echo e($committee->ComTask); ?></td>
                                    <td><?php echo e($committee->ComLeader); ?></td>
                                    <td><?php echo e($committee->ComDate); ?></td>
                                    <td>
                                        <a href="#" data-toggle="modal" data-target="#editCommittee"><button
                                                class="btn btn-success"><i class="fa fa-pen" aria-hidden="true"></i></button></a>
                                        <a href="#" data-toggle="modal" data-target="#deleteCommittee"><button
                                                class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></button></a>
                                    </td>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal: Add-->
    <div class="modal fade" id="createCommittee" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah AJK</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="<?php echo e(route('committee.store')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <label for="name" class="form-label">Nama Pekerja</label>
                            <select id="SID" name="SID" class="form-control" required>
                                <option value="" disabled selected>Sila Pilih </option>

                                <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staffs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e(sprintf('%012d',$staffs->SID )); ?>"><?php echo e($staffs->SName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="PosID">Jawatan :</label>
                            <select id="PosID" name="PosID" class="form-control" required>
                                <option value="" disabled selected>Sila Pilih </option>
                                <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $positions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($positions->PosID); ?>"><?php echo e($positions->PosName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="ComTask" class="form-label">Tugasan</label>
                            <input type="text" class="form-control" id="ComTask" name="ComTask"
                                oninput="this.value = this.value.toUpperCase()">
                        </div>

                        <div class="mb-3">
                            <label for="ComLeader">Ketua:</label>
                            <select id="ComLeader" name="ComLeader" class="form-control" required>
                                <option value="" disabled selected>Sila Pilih </option>
                                <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($staff->SName); ?>"><?php echo e($staff->SName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="ComDate">Tarikh Lantikan:</label>
                            <input type="date" id="ComDate" name="ComDate" class="form-control" required>
                        </div>

                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                            <button class="btn btn-primary" type="submit">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Modal: Add-->
    <!-- Modal: Edit-->
    <div class="modal fade" id="editCommittee" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Kemaskini Kakitangan</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="<?php echo e(url('committee/' . $committee->ComID)); ?>" id="editCommittee">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>


                        <div class="mb-3">
                            <label>Nama Pekerja</label><br>
                            <input type="text" readonly value="<?php echo e(optional($committee->staff)->SName); ?>"
                                class="form-control"><br>
                            <input type="hidden" name="SID" value="<?php echo e(optional($committee->staff)->SID); ?>" />
                        </div>

                        <div class="mb-3">
                            <label for="PosID">Jawatan:</label>
                            <select name="PosID" class="form-control" required>
                                <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pos->PosID); ?>" <?php if($pos->PosID == $committee->PosID): ?> selected <?php endif; ?>>
                                        <?php echo e($pos->PosName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="mb-3">

                            <label>Tugasan</label><br>
                            <input type="text" name="ComTask" value="<?php echo e($committee->ComTask); ?>" class="form-control"
                                required><br>

                        </div>

                        <div class="mb-3">
                            <label for="ComLeader">Ketua:</label>
                            <select name="ComLeader" class="form-control" required>
                                <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stafff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=""  selected>
                                        </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">

                            <label>Tarikh Lantikan</label><br>
                            <input type="date" name="ComDate" value="<?php echo e($committee->ComDate); ?>" class="form-control"
                                required><br>
                        </div>


                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                            <button class="btn btn-primary" type="submit">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal: Delete-->
    <div class="modal fade" id="deleteCommittee" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Hapus AJK</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form method="POST" action="<?php echo e(url('committee/' . $committee->ComID)); ?>" id="deleteCommittee">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <div class="modal-body">
                        <input type="hidden" name="_method" value="DELETE">
                        <p>Adakah anda pasti ingin menghapus AJK ini?</p>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Tutup</button>
                        <button class="btn btn-primary" type="submit">Hapus</button>
                    </div>



                    <script>
                        document.getElementById("PosName").addEventListener("input", function() {
                            this.value = this.value.toUpperCase();
                        });
                    </script>
                <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FYPNEWW\resources\views/admin/listAllCommittee.blade.php ENDPATH**/ ?>