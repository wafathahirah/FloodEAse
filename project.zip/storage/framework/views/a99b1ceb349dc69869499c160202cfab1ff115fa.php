
<?php $__env->startSection('content'); ?>
<link rel="stylesheet"
          href=
"https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />
    <link rel="stylesheet"
         
          integrity=
"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
          crossorigin="anonymous">
  
    <div class="container-xl px-4 mt-4">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

        <hr class="mt-0 mb-4">
        <div class="row">
            <div class="col-xl-4">
                <div class="card mb-4 mb-xl-0 shadow">
                    <div class="card mb-4 mb-xl-0">
                        <div class="card-body text-center">
                            <h5 class=" card-header m-0 font-weight-bold"><?php echo e(session('user')); ?></h5><br>
                            <a href="#" data-toggle="modal" data-target="#ResetPassword">Tukar Kata Laluan</a>

                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-8">
                <!-- update profile -->
                <div class="card mb-4 shadow">
                    <div class="card-header m-0 font-weight-bold text-primary"> Kemaskini Profil</div>
                    <div class="card-body">
                        <form id="send-verification" method="post" action="<?php echo e(route('verification.send')); ?>">
                            <?php echo csrf_field(); ?>
                        </form>

                        <form method="post" action="<?php echo e(route('profile.AdminUpdate')); ?>" class="mt-6 space-y-6">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>

                            <!-- Form Row-->
                            <div class="mb-3">
                                <label class="small mb-1" for="address">Alamat</label>
                                <input class="form-control" id="SAddress" name="SAddress" type="text" value="<?php echo e($staff->SAddress); ?>" 
                                oninput="this.value = this.value.toUpperCase()">
                            </div>
                            <!-- Form Row-->
                            <div class="mb-3">

                                <label class="small mb-1" for="phoneNum">Nombor Telefon</label>
                                <input class="form-control" id="SPhoneNum" name="SPhoneNum" type="text" value="<?php echo e($staff->SPhoneNum); ?>">

                            </div>
                            <!-- Form Row        -->
                            <div class="mb-3">

                                <label class="small mb-1" for="email">Emel</label>
                                <input class="form-control" id="SEmail" name="SEmail" type="email"
                                    value="<?php echo e(old('email', $user->email)); ?>">
                                <?php if($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && !$user->hasVerifiedEmail()): ?>
                                    <div id="verification-section">
                                        <p class="text-sm mt-2 text-gray-800">
                                            <?php echo e(__('Your email address is unverified.')); ?>


                                            <button form="send-verification"
                                                class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                                <?php echo e(__('Click here to re-send the verification email.')); ?>

                                            </button>
                                        </p>

                                        <?php if(session('status') === 'verification-link-sent'): ?>
                                            <p class="mt-2 font-medium text-sm text-green-600">
                                                <?php echo e(__('A new verification link has been sent to your email address.')); ?>

                                            </p>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Save changes button-->
                            <button class="btn btn-primary" type="submit" onclick="showSavedMessage()">Simpan</button>
                            <?php if(session('status') === 'profile-updated'): ?>
                            <p id="saved-message" class="text-sm text-gray-600">Saved.</p>

                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- Modal new password -->
    <div class="modal fade" id="ResetPassword" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tukar Kata Laluan</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" action="<?php echo e(route('password.update')); ?>" class="mt-6 space-y-6">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
            
                    <div class="mb-3">
                        <label for="current_password" class="form-label">Kata Laluan Sekarang</label>
                        <div class="input-group">
                            <input class="form-control" id="current_password" name="current_password" type="password">
                            <span class="input-group-text toggle-password" onclick="togglePassword('current_password')">
                                <i class="bi bi-eye-slash"></i>
                            </span>
                        </div>
                    </div>
            
                    <div class="mb-3">
                        <label for="password" class="form-label">Kata Laluan Baru</label>
                        <div class="input-group">
                            <input class="form-control" id="password" name="password" type="password">
                            <span class="input-group-text toggle-password" onclick="togglePassword('password')">
                                <i class="bi bi-eye-slash"></i>
                            </span>
                        </div>
                    </div>
            
                    <div class="mb-3">
                        <label for="password_confirmation" class="form-label">Ulang Kata Laluan</label>
                        <div class="input-group">
                            <input class="form-control" id="password_confirmation" name="password_confirmation" type="password">
                            <span class="input-group-text toggle-password" onclick="togglePassword('password_confirmation')">
                                <i class="bi bi-eye-slash"></i>
                            </span>
                        </div>
                    </div>
            
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                        <button class="btn btn-primary" type="submit">Simpan</button>
                        <?php if(session('status') === 'profile-updated'): ?>
                            <p id="saved-message" class="text-sm text-gray-600">Saved.</p>
                        <?php endif; ?>
                    </div>
                </form>
            
        </div>
    </div>
</div>
    </div>
    
    <script>
        function resendVerification() {
            document.getElementById('send-verification').submit();
        }

        function showSavedMessage() {
            var savedMessage = document.getElementById('saved-message');
            if (savedMessage) {
                savedMessage.style.display = 'block';
                setTimeout(function() {
                    savedMessage.style.display = 'none';
                }, 2000);
            }
        }

        function togglePassword(fieldId) {
                        const passwordInput = document.getElementById(fieldId);
                        const icon = document.querySelector(`#${fieldId} + .input-group-text i`);
            
                        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                        passwordInput.setAttribute('type', type);
                        icon.className = type === 'password' ? 'bi bi-eye-slash' : 'bi bi-eye';
                    }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FYPNEWW\resources\views/admin/profile.blade.php ENDPATH**/ ?>