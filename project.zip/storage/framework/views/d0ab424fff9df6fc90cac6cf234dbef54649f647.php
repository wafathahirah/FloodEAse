 <!-- Modal: Delete-->
 <div class="modal fade" id="deleteJKK<?php echo e($JKK->JKKID); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Hapus JawatanKuasa Kampung</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form method="POST" action="<?php echo e(route('destroy.jkk', $JKK->JKKID)); ?>" id="deleteJKK">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('DELETE')); ?>

                <div class="modal-body">
                <p>Adakah anda pasti ingin menghapus jawatankuasa kampung ini?</p>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Tutup</button>
            <button class="btn btn-primary" type="submit">Hapus</button>
        </div><?php /**PATH C:\xampp\htdocs\FYPNEWW - Copy\resources\views/admin/deleteJKK.blade.php ENDPATH**/ ?>