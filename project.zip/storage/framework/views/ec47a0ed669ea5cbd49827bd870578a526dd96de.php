
<?php $__env->startSection('content'); ?>
    <link href="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Inventori</h1>
            <a data-toggle="modal" data-target="#createAid"
                class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                    class="fas fa-plus fa-sm text-white-50"></i></a>
        </div>

        <!-- DataTable -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="listAid" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Nama Item</th>
                                <th>Jumlah</th> 
                                <th>Pakej</th>
                                <th>Masa/tarikh kemaskini</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Nama Item</th>
                                <th>Jumlah</th> 
                                <th>Pakej</th>
                                <th>Masa/tarikh kemaskini</th>
                                <th></th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $aid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($aid->ItemName); ?></td>
                                    <td><?php echo e($aid->TotalAid); ?></td>
                                    <td><?php echo e($aid->AidType); ?></td>
                                    <td><?php echo e($aid->updated_at); ?></td>
                                    <td><a href="#" data-toggle="modal" data-target="#editAid"><button
                                                class="btn btn-success edit"><i class="fa fa-pen" aria-hidden="true"></i></button></a>
                                        <a href="#" data-toggle="modal" data-target="#deleteAid"><button
                                                class="btn btn-danger delete"><i class="fa fa-trash" aria-hidden="true"></i></button></a>
                                    </td>
                                    <td></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal: Add-->
    <div class="modal fade" id="createAid" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Barang</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="<?php echo e(route('aid.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama barang</label>
                            <input type="text" class="form-control" id="ItemName" name="ItemName" oninput="this.value = this.value.toUpperCase()">
                        </div>

                        <div class="mb-3">
                            <label for="total" class="form-label">Jumlah Barang</label>
                            <input type="number" class="form-control" id="TotalAid" name="TotalAid">
                        </div>

                        <div class="mb-3">
                            <label for="package" class="form-label">Pakej</label>
                            <select class="form-control" id="AidType" name="AidType">
                                <option value="" disabled selected>Sila Pilih </option>
                                <option value="Set Lelaki">Set Lelaki</option>
                                <option value="Set Perempuan">Set Perempuan</option>
                                <option value="Set Bayi">Set Bayi</option>
                                <option value="Makanan Sahaja">Makanan Sahaja</option>

                            </select>
                        </div>


                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                            <button class="btn btn-primary" type="submit">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Modal: Add-->
    <!-- Modal: Edit-->
    <div class="modal fade" id="editAid" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Kemaskini Barang</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="" id="editAid">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>


                        <div class="mb-3">
                            <label for="name" class="form-label">Nama barang</label>
                            <input type="text" class="form-control" id="ItemName" name="ItemName" oninput="this.value = this.value.toUpperCase()">
                        </div>

                        <div class="mb-3">
                            <label for="total" class="form-label">Jumlah Barang</label>
                            <input type="number" class="form-control" id="TotalAid" name="TotalAid">
                        </div>

                        <div class="mb-3">
                            <label for="package" class="form-label">Pakej</label>
                            <select class="form-control" id="AidType" name="AidType">
                                <option value="" disabled selected>Sila Pilih </option>
                                <option value="Set Lelaki">Set Lelaki</option>
                                <option value="Set Perempuan">Set Perempuan</option>
                                <option value="Set Bayi">Set Bayi</option>
                                <option value="Makanan Sahaja">Makanan Sahaja</option>

                            </select>
                        </div>



                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                            <button class="btn btn-primary" type="submit">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal: Delete-->
    <div class="modal fade" id="deleteAid" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Hapus Barang</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form method="POST" action="" id="deleteAid">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <div class="modal-body">
                        <input type="hidden" name="_method" value="DELETE">
                        <p>Adakah anda pasti ingin menghapus barang ini?</p>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Tutup</button>
                        <button class="btn btn-primary" type="submit">Hapus</button>
                    </div>



                    <script>
                        document.getElementById("PosName").addEventListener("input", function() {
                            this.value = this.value.toUpperCase();
                        });
                    </script>
                <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\htdocs\FYPNEWW\resources\views/admin/listAllInventory.blade.php ENDPATH**/ ?>